<?php include('db_connect.php') ?>

<div class="col-lg-12">
  <div class="row">
    <?php include('about.html') ?>
  </div>
</div>